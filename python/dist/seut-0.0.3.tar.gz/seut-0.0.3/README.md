# Seut
Seut is Socicaly Network For System.
# About
seut can build uniquely designed networks to achieve high performance in a variety of environments.  
The Seut Liquidity Network provides basic tracking via logs with ease.  
The Seut Cell Network offers even more advanced performance, customized for different environments.
# JavaScript Library
## Seut JavaScript Library
This library can be installed with the following command
```bash
npm install seut
```
See /js/README.md or [this](https://www.npmjs.com/package/seut) for detailed instructions.
# Seut Python Library
```bash
pip3 install seut
```
# Maked By Carnation Studio 2024